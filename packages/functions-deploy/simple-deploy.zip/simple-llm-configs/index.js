module.exports = async function (context, req) {
    try {
        context.log('LLM configs API called - Australia East');

        // CORS headers
        const corsHeaders = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, x-tenant-id'
        };

        // Handle preflight OPTIONS request
        if (req.method === 'OPTIONS') {
            context.res = {
                status: 200,
                headers: corsHeaders
            };
            return;
        }

        if (req.method === 'GET') {
            // Return mock LLM configurations
            const responseBody = {
                success: true,
                message: 'Australia East backend working!',
                data: [
                    {
                        config_id: '1',
                        id: '1',
                        name: 'Australia East LLM Config',
                        provider: 'openai',
                        model: 'gpt-4',
                        temperature: 0.7,
                        maxTokens: 2000,
                        created: new Date().toISOString()
                    }
                ]
            };

            context.res = {
                status: 200,
                headers: {
                    'Content-Type': 'application/json',
                    ...corsHeaders
                },
                body: responseBody
            };
        } else {
            context.res = {
                status: 405,
                headers: {
                    'Content-Type': 'application/json',
                    ...corsHeaders
                },
                body: { success: false, error: 'Method not allowed' }
            };
        }
    } catch (error) {
        context.log.error('Function error:', error);
        context.res = {
            status: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: {
                success: false,
                error: error.message,
                stack: error.stack
            }
        };
    }
};