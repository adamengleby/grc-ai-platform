const { app } = require('@azure/functions');

app.http('simple-llm-configs', {
    methods: ['GET', 'POST', 'OPTIONS'],
    authLevel: 'anonymous',
    route: 'v1/simple-llm-configs',
    handler: async (request, context) => {
        context.log('Australia East Function called!');

        const corsHeaders = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, x-tenant-id'
        };

        if (request.method === 'OPTIONS') {
            return {
                status: 200,
                headers: corsHeaders
            };
        }

        return {
            status: 200,
            headers: {
                'Content-Type': 'application/json',
                ...corsHeaders
            },
            jsonBody: {
                success: true,
                message: '🇦🇺 Australia East backend is working!',
                data: [
                    {
                        config_id: '1',
                        id: '1',
                        name: 'Australia East LLM Config',
                        provider: 'openai',
                        model: 'gpt-4',
                        temperature: 0.7,
                        maxTokens: 2000,
                        created: new Date().toISOString()
                    }
                ]
            }
        };
    }
});