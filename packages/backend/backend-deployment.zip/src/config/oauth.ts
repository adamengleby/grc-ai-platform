// OAuth 2.0 + OIDC Configuration for Multi-tenant GRC Platform
import { ConfigParams } from 'express-openid-connect';

export interface TenantOAuthConfig {
  tenantId: string;
  tenantSlug: string;
  issuerBaseURL: string;
  clientID: string;
  clientSecret: string;
  audience?: string;
  scope?: string;
  redirectUri: string;
  postLogoutRedirectUri: string;
}

export interface Auth0Config extends ConfigParams {
  issuerBaseURL: string;
  clientID: string;
  clientSecret: string;
  baseURL: string;
  secret: string;
  authRequired: boolean;
  auth0Logout: boolean;
  session: {
    absoluteDuration: number;
    cookie: {
      httpOnly: boolean;
      secure: boolean;
      sameSite: 'Lax' | 'Strict' | 'None';
    };
  };
  authorizationParams: {
    response_type: 'code';
    audience?: string;
    scope: string;
  };
  routes: {
    login: string;
    logout: string;
    callback: string;
    postLogoutRedirect: string;
  };
}

// Default OAuth configuration for local development
export const getDefaultOAuthConfig = (): Auth0Config => {
  const baseURL = process.env.OAUTH_BASE_URL || 'http://localhost:3005';
  const frontendURL = process.env.FRONTEND_URL || 'http://localhost:5173';

  return {
    authRequired: false, // We'll handle this per route
    auth0Logout: true,
    secret: process.env.OAUTH_SECRET || 'your-super-secret-32-character-string-here',
    baseURL,
    
    // Auth0 Development Configuration
    issuerBaseURL: process.env.AUTH0_ISSUER_BASE_URL || 'https://dev-grc-platform.us.auth0.com',
    clientID: process.env.AUTH0_CLIENT_ID || 'your-auth0-client-id',
    clientSecret: process.env.AUTH0_CLIENT_SECRET || 'your-auth0-client-secret',

    // Session configuration
    session: {
      absoluteDuration: 8 * 60 * 60 * 1000, // 8 hours
      cookie: {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'Lax'
      }
    },

    // Authorization parameters
    authorizationParams: {
      response_type: 'code',
      audience: process.env.AUTH0_AUDIENCE,
      scope: 'openid profile email tenant:read agent:manage'
    },

    // Route configuration
    routes: {
      login: '/auth/login',
      logout: '/auth/logout',
      callback: '/auth/callback',
      postLogoutRedirect: frontendURL + '/login'
    }
  };
};

// Multi-tenant OAuth configuration
export class MultiTenantOAuthManager {
  private tenantConfigs: Map<string, TenantOAuthConfig> = new Map();
  
  constructor() {
    this.loadDefaultTenantConfigs();
  }

  // Load default tenant configurations for demo
  private loadDefaultTenantConfigs(): void {
    const defaultTenants: TenantOAuthConfig[] = [
      {
        tenantId: 'acme-corp',
        tenantSlug: 'acme',
        issuerBaseURL: 'https://dev-grc-platform.us.auth0.com',
        clientID: process.env.AUTH0_CLIENT_ID || 'acme-client-id',
        clientSecret: process.env.AUTH0_CLIENT_SECRET || 'acme-client-secret',
        audience: 'https://api.acme-corp.grc-platform.com',
        scope: 'openid profile email tenant:read agent:manage',
        redirectUri: 'http://localhost:3005/auth/acme/callback',
        postLogoutRedirectUri: 'http://localhost:5173/login?tenant=acme'
      },
      {
        tenantId: 'fintech-solutions',
        tenantSlug: 'fintech',
        issuerBaseURL: 'https://dev-grc-platform.us.auth0.com',
        clientID: process.env.AUTH0_CLIENT_ID || 'fintech-client-id',
        clientSecret: process.env.AUTH0_CLIENT_SECRET || 'fintech-client-secret',
        audience: 'https://api.fintech-solutions.grc-platform.com',
        scope: 'openid profile email tenant:read',
        redirectUri: 'http://localhost:3005/auth/fintech/callback',
        postLogoutRedirectUri: 'http://localhost:5173/login?tenant=fintech'
      }
    ];

    defaultTenants.forEach(config => {
      this.tenantConfigs.set(config.tenantSlug, config);
    });
  }

  // Get OAuth config for a specific tenant
  getTenantConfig(tenantSlug: string): TenantOAuthConfig | null {
    return this.tenantConfigs.get(tenantSlug) || null;
  }

  // Get Auth0 config for a tenant
  getAuth0ConfigForTenant(tenantSlug: string): Auth0Config | null {
    const tenantConfig = this.getTenantConfig(tenantSlug);
    if (!tenantConfig) return null;

    const baseConfig = getDefaultOAuthConfig();
    
    return {
      ...baseConfig,
      issuerBaseURL: tenantConfig.issuerBaseURL,
      clientID: tenantConfig.clientID,
      clientSecret: tenantConfig.clientSecret,
      authorizationParams: {
        ...baseConfig.authorizationParams,
        audience: tenantConfig.audience,
        scope: tenantConfig.scope
      },
      routes: {
        login: `/auth/${tenantSlug}/login`,
        logout: `/auth/${tenantSlug}/logout`,
        callback: `/auth/${tenantSlug}/callback`,
        postLogoutRedirect: tenantConfig.postLogoutRedirectUri || '/login'
      }
    };
  }

  // Add or update tenant OAuth configuration
  setTenantConfig(tenantSlug: string, config: TenantOAuthConfig): void {
    this.tenantConfigs.set(tenantSlug, config);
  }

  // Get all tenant slugs
  getTenantSlugs(): string[] {
    return Array.from(this.tenantConfigs.keys());
  }

  // Discover tenant from subdomain or domain
  discoverTenantFromRequest(host: string): string | null {
    // Example: acme.grc-platform.com -> 'acme'
    const subdomain = host.split('.')[0];
    
    // Check if it's a known tenant
    if (this.tenantConfigs.has(subdomain)) {
      return subdomain;
    }

    // For localhost development, check query params or path
    return null;
  }

  // Validate tenant configuration
  validateTenantConfig(config: TenantOAuthConfig): boolean {
    return !!(
      config.tenantId &&
      config.tenantSlug &&
      config.issuerBaseURL &&
      config.clientID &&
      config.clientSecret &&
      config.redirectUri
    );
  }
}

// Export singleton instance
export const oauthManager = new MultiTenantOAuthManager();

// JWT validation configuration for API routes
export const getJWTValidationConfig = (tenantSlug?: string) => {
  const config = tenantSlug 
    ? oauthManager.getAuth0ConfigForTenant(tenantSlug)
    : getDefaultOAuthConfig();

  if (!config) {
    throw new Error(`OAuth configuration not found for tenant: ${tenantSlug}`);
  }

  return {
    issuerBaseURL: config.issuerBaseURL,
    audience: config.authorizationParams?.audience,
    algorithms: ['RS256'] as const,
    jwksUri: `${config.issuerBaseURL}/.well-known/jwks.json`
  };
};

// Environment validation
export const validateOAuthEnvironment = (): boolean => {
  const required = [
    'OAUTH_SECRET',
    'AUTH0_ISSUER_BASE_URL',
    'AUTH0_CLIENT_ID',
    'AUTH0_CLIENT_SECRET'
  ];

  const missing = required.filter(key => !process.env[key]);
  
  if (missing.length > 0) {
    console.warn('Missing OAuth environment variables:', missing);
    console.warn('Using default configuration for development. Set these in production.');
    return false;
  }

  return true;
};