-- Multi-Tenant SaaS Platform Database Schema for GRC AI Platform
-- Designed for Azure Cosmos DB (Core SQL API) or Azure SQL Database
-- All tables are tenant-partitioned for proper multi-tenant isolation

-- =====================================================
-- CORE TENANT MANAGEMENT
-- =====================================================

-- Tenants table - Core tenant information with UUID primary keys
CREATE TABLE tenants (
    tenant_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    name NVARCHAR(255) NOT NULL,
    slug NVARCHAR(100) NOT NULL UNIQUE, -- URL-friendly identifier
    subscription_tier NVARCHAR(50) NOT NULL DEFAULT 'starter', -- starter, professional, enterprise
    status NVARCHAR(50) NOT NULL DEFAULT 'active', -- active, suspended, provisioning, terminated
    region NVARCHAR(50) NOT NULL DEFAULT 'eastus',
    
    -- Settings stored as JSON for flexibility
    settings NVARCHAR(MAX) DEFAULT '{}' CHECK (ISJSON(settings) = 1),
    quota_config NVARCHAR(MAX) DEFAULT '{}' CHECK (ISJSON(quota_config) = 1),
    
    -- Azure Key Vault reference for tenant-specific secrets
    keyvault_name NVARCHAR(255), -- Tenant-specific Key Vault instance
    
    -- Timestamps
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    
    -- Soft delete support
    deleted_at DATETIME2 NULL,
    
    INDEX IX_tenants_slug (slug),
    INDEX IX_tenants_status (status),
    INDEX IX_tenants_created_at (created_at)
);

-- Users table - Azure AD B2C integrated users with tenant associations
CREATE TABLE users (
    user_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    azure_b2c_object_id NVARCHAR(255) UNIQUE NOT NULL, -- Azure AD B2C Object ID
    email NVARCHAR(320) NOT NULL,
    name NVARCHAR(255) NOT NULL,
    
    -- Primary tenant association
    primary_tenant_id UNIQUEIDENTIFIER NOT NULL,
    
    -- User status and security
    status NVARCHAR(50) NOT NULL DEFAULT 'active', -- active, suspended, pending_verification
    mfa_enabled BIT DEFAULT 0,
    last_login_at DATETIME2,
    password_last_changed DATETIME2,
    
    -- Timestamps
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    deleted_at DATETIME2 NULL,
    
    FOREIGN KEY (primary_tenant_id) REFERENCES tenants(tenant_id),
    INDEX IX_users_azure_b2c_object_id (azure_b2c_object_id),
    INDEX IX_users_email (email),
    INDEX IX_users_primary_tenant_id (primary_tenant_id),
    INDEX IX_users_status (status)
);

-- User-Tenant-Role associations (many-to-many with roles)
CREATE TABLE user_tenant_roles (
    id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    user_id UNIQUEIDENTIFIER NOT NULL,
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    role NVARCHAR(50) NOT NULL, -- PlatformOwner, TenantOwner, AgentUser, Auditor, ComplianceOfficer
    
    -- Permission grants and restrictions
    permissions NVARCHAR(MAX) DEFAULT '[]' CHECK (ISJSON(permissions) = 1),
    
    -- Assignment metadata
    assigned_by_user_id UNIQUEIDENTIFIER,
    assigned_at DATETIME2 DEFAULT GETUTCDATE(),
    expires_at DATETIME2,
    
    -- Timestamps
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (assigned_by_user_id) REFERENCES users(user_id),
    
    -- Composite indexes for efficient queries
    INDEX IX_user_tenant_roles_user_tenant (user_id, tenant_id),
    INDEX IX_user_tenant_roles_tenant_role (tenant_id, role),
    UNIQUE (user_id, tenant_id, role) -- Prevent duplicate role assignments
);

-- =====================================================
-- AI AGENT CONFIGURATION
-- =====================================================

-- AI Agents - Replaces localStorage agent storage
CREATE TABLE ai_agents (
    agent_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    
    -- Agent configuration
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX),
    persona NVARCHAR(MAX),
    system_prompt NVARCHAR(MAX),
    
    -- LLM and MCP configuration
    llm_config_id UNIQUEIDENTIFIER,
    enabled_mcp_servers NVARCHAR(MAX) DEFAULT '[]' CHECK (ISJSON(enabled_mcp_servers) = 1), -- JSON array of server IDs
    
    -- Agent presentation
    avatar NVARCHAR(255),
    color NVARCHAR(7), -- Hex color code
    
    -- Status and usage
    is_enabled BIT DEFAULT 1,
    usage_count INT DEFAULT 0,
    last_used_at DATETIME2,
    
    -- Agent lifecycle
    created_by_user_id UNIQUEIDENTIFIER,
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    deleted_at DATETIME2 NULL,
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (created_by_user_id) REFERENCES users(user_id),
    
    -- Tenant partitioning and performance indexes
    INDEX IX_ai_agents_tenant_id (tenant_id),
    INDEX IX_ai_agents_tenant_enabled (tenant_id, is_enabled),
    INDEX IX_ai_agents_usage (tenant_id, usage_count DESC),
    INDEX IX_ai_agents_last_used (tenant_id, last_used_at DESC)
);

-- =====================================================
-- LLM CONFIGURATION MANAGEMENT
-- =====================================================

-- LLM Configurations - Replaces localStorage LLM config storage
CREATE TABLE llm_configurations (
    config_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    
    -- Configuration details
    name NVARCHAR(255) NOT NULL,
    provider NVARCHAR(50) NOT NULL, -- azure_openai, openai, anthropic
    model NVARCHAR(100) NOT NULL,
    
    -- LLM parameters
    temperature FLOAT DEFAULT 0.3,
    max_tokens INT DEFAULT 2000,
    response_format NVARCHAR(50) DEFAULT 'text', -- text, json_object
    
    -- Authentication (references to Azure Key Vault)
    api_key_vault_secret NVARCHAR(255), -- Key Vault secret name for API key
    endpoint_vault_secret NVARCHAR(255), -- Key Vault secret name for endpoint URL
    
    -- Configuration status
    is_enabled BIT DEFAULT 1,
    is_default BIT DEFAULT 0, -- Only one default per tenant
    
    -- Validation and testing
    last_tested_at DATETIME2,
    last_test_status NVARCHAR(50), -- success, failed, pending
    last_test_error NVARCHAR(MAX),
    
    -- Usage tracking for billing/quotas
    usage_count INT DEFAULT 0,
    total_tokens_used BIGINT DEFAULT 0,
    
    -- Lifecycle
    created_by_user_id UNIQUEIDENTIFIER,
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    deleted_at DATETIME2 NULL,
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (created_by_user_id) REFERENCES users(user_id),
    
    -- Tenant partitioning and performance
    INDEX IX_llm_configurations_tenant_id (tenant_id),
    INDEX IX_llm_configurations_tenant_enabled (tenant_id, is_enabled),
    INDEX IX_llm_configurations_tenant_default (tenant_id, is_default),
    UNIQUE IX_llm_configurations_tenant_name (tenant_id, name) WHERE deleted_at IS NULL
);

-- =====================================================
-- GLOBAL MCP SERVER REGISTRY
-- =====================================================

-- Global MCP Server Registry - Platform-level approved servers
CREATE TABLE mcp_server_registry (
    server_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    
    -- Server identification
    name NVARCHAR(255) NOT NULL UNIQUE,
    display_name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX),
    category NVARCHAR(100), -- grc, productivity, integration, etc.
    
    -- Server configuration
    server_type NVARCHAR(50) NOT NULL, -- stdio, sse, websocket
    executable_path NVARCHAR(500),
    args NVARCHAR(MAX), -- JSON array of arguments
    env NVARCHAR(MAX), -- JSON object of environment variables
    
    -- Capabilities and tools
    available_tools NVARCHAR(MAX), -- JSON array of tool definitions
    required_permissions NVARCHAR(MAX), -- JSON array of required permissions
    
    -- Registry metadata
    version NVARCHAR(50),
    vendor NVARCHAR(255),
    documentation_url NVARCHAR(500),
    icon_url NVARCHAR(500),
    
    -- Approval and compliance
    is_approved BIT DEFAULT 0,
    compliance_frameworks NVARCHAR(MAX), -- JSON array of supported frameworks
    security_review_status NVARCHAR(50), -- pending, approved, rejected
    security_review_notes NVARCHAR(MAX),
    
    -- Platform management
    created_by_user_id UNIQUEIDENTIFIER,
    approved_by_user_id UNIQUEIDENTIFIER,
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    approved_at DATETIME2,
    
    FOREIGN KEY (created_by_user_id) REFERENCES users(user_id),
    FOREIGN KEY (approved_by_user_id) REFERENCES users(user_id),
    
    INDEX IX_mcp_server_registry_name (name),
    INDEX IX_mcp_server_registry_category (category),
    INDEX IX_mcp_server_registry_approved (is_approved),
    INDEX IX_mcp_server_registry_security_status (security_review_status)
);

-- =====================================================
-- TENANT MCP SERVER CONFIGURATIONS
-- =====================================================

-- Tenant MCP Server Enablement - Which servers are enabled per tenant
CREATE TABLE tenant_mcp_servers (
    id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    server_id UNIQUEIDENTIFIER NOT NULL, -- References mcp_server_registry
    
    -- Tenant-specific configuration
    is_enabled BIT DEFAULT 1,
    custom_name NVARCHAR(255), -- Tenant can rename servers
    configuration_values NVARCHAR(MAX) DEFAULT '{}' CHECK (ISJSON(configuration_values) = 1), -- Server-specific config
    
    -- Scope restrictions (subset of global server capabilities)
    allowed_tools NVARCHAR(MAX), -- JSON array - subset of server's available_tools
    restricted_permissions NVARCHAR(MAX), -- JSON array - additional restrictions beyond server defaults
    
    -- Usage and monitoring
    usage_count INT DEFAULT 0,
    last_used_at DATETIME2,
    health_status NVARCHAR(50) DEFAULT 'unknown', -- healthy, unhealthy, unknown, disabled
    last_health_check DATETIME2,
    
    -- Configuration management
    enabled_by_user_id UNIQUEIDENTIFIER,
    enabled_at DATETIME2 DEFAULT GETUTCDATE(),
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (server_id) REFERENCES mcp_server_registry(server_id),
    FOREIGN KEY (enabled_by_user_id) REFERENCES users(user_id),
    
    -- Tenant partitioning and performance
    INDEX IX_tenant_mcp_servers_tenant_id (tenant_id),
    INDEX IX_tenant_mcp_servers_tenant_enabled (tenant_id, is_enabled),
    INDEX IX_tenant_mcp_servers_server_id (server_id),
    UNIQUE IX_tenant_mcp_servers_tenant_server (tenant_id, server_id) -- One enablement record per tenant-server pair
);

-- =====================================================
-- ARCHER CONNECTIONS & CREDENTIALS
-- =====================================================

-- Archer Connections - Tenant's GRC platform connections (stored with encryption)
CREATE TABLE archer_connections (
    connection_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    
    -- Connection identification
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX),
    
    -- Connection details (stored as encrypted JSON in Key Vault)
    connection_config_vault_secret NVARCHAR(255), -- Key Vault secret containing connection details
    
    -- Connection status
    is_active BIT DEFAULT 1,
    last_test_status NVARCHAR(50), -- success, failed, pending
    last_tested_at DATETIME2,
    last_test_error NVARCHAR(MAX),
    
    -- Usage tracking
    usage_count INT DEFAULT 0,
    last_used_at DATETIME2,
    
    -- Lifecycle
    created_by_user_id UNIQUEIDENTIFIER,
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    deleted_at DATETIME2 NULL,
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (created_by_user_id) REFERENCES users(user_id),
    
    INDEX IX_archer_connections_tenant_id (tenant_id),
    INDEX IX_archer_connections_tenant_active (tenant_id, is_active),
    UNIQUE IX_archer_connections_tenant_name (tenant_id, name) WHERE deleted_at IS NULL
);

-- =====================================================
-- AUDIT AND COMPLIANCE LOGGING
-- =====================================================

-- Comprehensive audit log for all tenant operations
CREATE TABLE audit_events (
    event_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    
    -- Event classification
    event_type NVARCHAR(100) NOT NULL, -- agent_created, llm_config_modified, mcp_server_enabled, etc.
    event_category NVARCHAR(50) NOT NULL, -- security, configuration, usage, compliance
    severity NVARCHAR(20) NOT NULL, -- info, warning, error, critical
    
    -- Event context
    user_id UNIQUEIDENTIFIER,
    user_email NVARCHAR(320),
    resource_type NVARCHAR(50), -- agent, llm_config, mcp_server, etc.
    resource_id UNIQUEIDENTIFIER,
    
    -- Event details
    event_summary NVARCHAR(500),
    event_details NVARCHAR(MAX), -- JSON with full event context
    
    -- Request context
    client_ip NVARCHAR(45),
    user_agent NVARCHAR(500),
    request_id UNIQUEIDENTIFIER,
    session_id NVARCHAR(255),
    
    -- Compliance and forensics
    compliance_frameworks NVARCHAR(MAX), -- JSON array of applicable frameworks
    before_state NVARCHAR(MAX), -- JSON snapshot before change
    after_state NVARCHAR(MAX), -- JSON snapshot after change
    
    -- Tamper detection
    event_hash NVARCHAR(64), -- SHA-256 hash for integrity verification
    
    -- Timestamps (immutable)
    event_timestamp DATETIME2 DEFAULT GETUTCDATE(),
    ingested_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    
    -- Optimized for audit queries
    INDEX IX_audit_events_tenant_timestamp (tenant_id, event_timestamp DESC),
    INDEX IX_audit_events_tenant_type (tenant_id, event_type),
    INDEX IX_audit_events_tenant_category (tenant_id, event_category),
    INDEX IX_audit_events_user_id (user_id),
    INDEX IX_audit_events_resource (resource_type, resource_id),
    INDEX IX_audit_events_compliance (tenant_id, event_timestamp DESC) INCLUDE (compliance_frameworks)
);

-- =====================================================
-- USAGE METRICS AND ANALYTICS
-- =====================================================

-- Agent usage metrics for analytics and billing
CREATE TABLE agent_usage_metrics (
    metric_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    agent_id UNIQUEIDENTIFIER NOT NULL,
    
    -- Usage period
    period_start DATETIME2 NOT NULL,
    period_end DATETIME2 NOT NULL,
    period_type NVARCHAR(20) NOT NULL, -- hour, day, week, month
    
    -- Usage statistics
    total_requests INT DEFAULT 0,
    total_tokens_consumed BIGINT DEFAULT 0,
    average_response_time_ms INT DEFAULT 0,
    error_count INT DEFAULT 0,
    
    -- Cost tracking
    estimated_cost DECIMAL(10,4) DEFAULT 0.0000,
    currency NVARCHAR(3) DEFAULT 'USD',
    
    -- Tool usage breakdown
    tools_used NVARCHAR(MAX), -- JSON object with tool usage counts
    
    -- Quality metrics
    user_satisfaction_score DECIMAL(3,2), -- Average rating if available
    
    -- Metadata
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (agent_id) REFERENCES ai_agents(agent_id),
    
    -- Performance optimized for analytics queries
    INDEX IX_agent_usage_metrics_tenant_period (tenant_id, period_start DESC),
    INDEX IX_agent_usage_metrics_agent_period (agent_id, period_start DESC),
    UNIQUE IX_agent_usage_metrics_unique_period (tenant_id, agent_id, period_start, period_type)
);

-- =====================================================
-- SESSION AND CHAT MANAGEMENT  
-- =====================================================

-- Chat sessions - Replace localStorage chat history with persistent, tenant-isolated storage
CREATE TABLE chat_sessions (
    session_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    user_id UNIQUEIDENTIFIER NOT NULL,
    agent_id UNIQUEIDENTIFIER NOT NULL,
    
    -- Session metadata
    session_name NVARCHAR(255),
    session_context NVARCHAR(MAX), -- JSON context for the chat session
    
    -- Session state
    is_active BIT DEFAULT 1,
    last_message_at DATETIME2 DEFAULT GETUTCDATE(),
    message_count INT DEFAULT 0,
    
    -- Privacy and retention
    retention_policy NVARCHAR(50) DEFAULT 'standard', -- standard, extended, minimal
    auto_delete_at DATETIME2, -- Auto-cleanup date
    
    -- Timestamps
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    deleted_at DATETIME2 NULL,
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (agent_id) REFERENCES ai_agents(agent_id),
    
    INDEX IX_chat_sessions_tenant_user (tenant_id, user_id),
    INDEX IX_chat_sessions_tenant_agent (tenant_id, agent_id),
    INDEX IX_chat_sessions_active (tenant_id, is_active),
    INDEX IX_chat_sessions_cleanup (auto_delete_at) WHERE auto_delete_at IS NOT NULL
);

-- Chat messages within sessions
CREATE TABLE chat_messages (
    message_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    session_id UNIQUEIDENTIFIER NOT NULL,
    tenant_id UNIQUEIDENTIFIER NOT NULL, -- Denormalized for partition efficiency
    
    -- Message content
    role NVARCHAR(20) NOT NULL, -- user, assistant, system, tool
    content NVARCHAR(MAX), -- Message content
    content_type NVARCHAR(50) DEFAULT 'text', -- text, json, markdown
    
    -- Tool execution context
    tool_calls NVARCHAR(MAX), -- JSON array of tool calls if applicable
    tool_call_id NVARCHAR(255), -- Reference to specific tool call
    
    -- Message metadata
    sequence_number INT NOT NULL, -- Order within session
    tokens_used INT DEFAULT 0,
    processing_time_ms INT DEFAULT 0,
    
    -- Privacy and redaction
    contains_pii BIT DEFAULT 0,
    redacted_content NVARCHAR(MAX), -- PII-redacted version for audit trails
    
    -- Timestamps
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (session_id) REFERENCES chat_sessions(session_id),
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    
    -- Optimized for session retrieval
    INDEX IX_chat_messages_session_sequence (session_id, sequence_number),
    INDEX IX_chat_messages_tenant_created (tenant_id, created_at DESC),
    UNIQUE IX_chat_messages_session_sequence_unique (session_id, sequence_number)
);

-- =====================================================
-- PERFORMANCE AND MONITORING
-- =====================================================

-- System health and performance metrics
CREATE TABLE system_metrics (
    metric_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER, -- NULL for global metrics
    
    -- Metric identification
    metric_name NVARCHAR(100) NOT NULL,
    metric_category NVARCHAR(50) NOT NULL, -- performance, availability, security, usage
    
    -- Metric values
    metric_value DECIMAL(18,6),
    metric_unit NVARCHAR(20), -- ms, percentage, count, bytes, etc.
    
    -- Context and tags
    tags NVARCHAR(MAX), -- JSON object with additional context
    
    -- Timestamp
    collected_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    
    -- Optimized for time-series queries
    INDEX IX_system_metrics_tenant_time (tenant_id, collected_at DESC),
    INDEX IX_system_metrics_name_time (metric_name, collected_at DESC),
    INDEX IX_system_metrics_category_time (metric_category, collected_at DESC)
);

-- =====================================================
-- DATA RETENTION AND CLEANUP POLICIES
-- =====================================================

-- Automated cleanup configuration per tenant
CREATE TABLE data_retention_policies (
    policy_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    
    -- Policy scope
    data_type NVARCHAR(50) NOT NULL, -- audit_events, chat_messages, usage_metrics, etc.
    retention_days INT NOT NULL,
    
    -- Policy rules
    archive_before_delete BIT DEFAULT 1, -- Archive to cold storage before deletion
    compliance_hold BIT DEFAULT 0, -- Legal/compliance hold prevents deletion
    
    -- Policy metadata
    policy_name NVARCHAR(255),
    policy_description NVARCHAR(MAX),
    
    -- Lifecycle
    is_active BIT DEFAULT 1,
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    
    UNIQUE IX_data_retention_tenant_type (tenant_id, data_type)
);

-- =====================================================
-- INITIAL TRIGGERS AND CONSTRAINTS
-- =====================================================

-- Trigger to ensure only one default LLM config per tenant
GO
CREATE TRIGGER tr_llm_configurations_default_constraint
ON llm_configurations
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- If setting a config as default, unset all other defaults for the same tenant
    UPDATE llm_configurations
    SET is_default = 0, updated_at = GETUTCDATE()
    WHERE tenant_id IN (SELECT tenant_id FROM inserted WHERE is_default = 1)
      AND config_id NOT IN (SELECT config_id FROM inserted WHERE is_default = 1)
      AND is_default = 1;
END;
GO

-- Trigger to update updated_at timestamps
CREATE TRIGGER tr_update_timestamps_tenants ON tenants AFTER UPDATE AS 
BEGIN
    UPDATE tenants SET updated_at = GETUTCDATE() WHERE tenant_id IN (SELECT tenant_id FROM inserted);
END;
GO

CREATE TRIGGER tr_update_timestamps_users ON users AFTER UPDATE AS 
BEGIN
    UPDATE users SET updated_at = GETUTCDATE() WHERE user_id IN (SELECT user_id FROM inserted);
END;
GO

CREATE TRIGGER tr_update_timestamps_ai_agents ON ai_agents AFTER UPDATE AS 
BEGIN
    UPDATE ai_agents SET updated_at = GETUTCDATE() WHERE agent_id IN (SELECT agent_id FROM inserted);
END;
GO

-- Add similar triggers for other tables as needed...

-- =====================================================
-- SAMPLE DATA FOR DEVELOPMENT
-- =====================================================

-- Sample tenant for development (can be removed in production)
INSERT INTO tenants (tenant_id, name, slug, subscription_tier, status, region, settings, quota_config)
VALUES (
    'A1B2C3D4-E5F6-7G8H-9I0J-K1L2M3N4O5P6',
    'Acme Corporation',
    'acme-corp',
    'professional',
    'active',
    'eastus',
    '{"enabledFeatures": ["ai_agents", "mcp_servers", "advanced_analytics"], "byoLlmEnabled": true, "auditRetentionDays": 2555}',
    '{"dailyApiCalls": 10000, "monthlyTokens": 5000000, "storageGB": 100, "users": 50}'
);

-- Sample platform admin user
INSERT INTO users (user_id, azure_b2c_object_id, email, name, primary_tenant_id, status, mfa_enabled)
VALUES (
    'U1A2B3C4-D5E6-F7G8-H9I0-J1K2L3M4N5O6',
    'b2c-admin-object-id-123',
    'admin@acmecorp.com',
    'Platform Administrator',
    'A1B2C3D4-E5F6-7G8H-9I0J-K1L2M3N4O5P6',
    'active',
    1
);

-- Sample platform admin role
INSERT INTO user_tenant_roles (user_id, tenant_id, role, assigned_at)
VALUES (
    'U1A2B3C4-D5E6-F7G8-H9I0-J1K2L3M4N5O6',
    'A1B2C3D4-E5F6-7G8H-9I0J-K1L2M3N4O5P6',
    'TenantOwner',
    GETUTCDATE()
);