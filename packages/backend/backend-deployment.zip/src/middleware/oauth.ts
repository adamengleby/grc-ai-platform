// OAuth 2.0 + OIDC Middleware for Multi-tenant GRC Platform
import { Request, Response, NextFunction } from 'express';
import { auth, requiresAuth } from 'express-openid-connect';
import { auth as jwtCheck } from 'express-oauth2-jwt-bearer';
import { oauthManager, getJWTValidationConfig } from '../config/oauth';
import winston from 'winston';

// Extend Express Request to include OAuth context
declare global {
  namespace Express {
    interface Request {
      oidc?: {
        isAuthenticated: () => boolean;
        user?: any;
        accessToken?: {
          access_token: string;
          token_type: string;
          expires_in: number;
          scope?: string;
        };
        idToken?: string;
        idTokenClaims?: any;
        refreshToken?: string;
      };
      tenantSlug?: string;
      tenantId?: string;
      userRoles?: string[];
      userPermissions?: string[];
    }
  }
}

// Tenant discovery middleware
export const discoverTenant = (req: Request, res: Response, next: NextFunction) => {
  try {
    let tenantSlug: string | null = null;

    // 1. Try subdomain discovery (production)
    const host = req.get('host') || '';
    tenantSlug = oauthManager.discoverTenantFromRequest(host);

    // 2. Try URL path discovery (/auth/{tenant}/*)
    const pathMatch = req.path.match(/^\/auth\/([^\/]+)/);
    if (pathMatch) {
      tenantSlug = pathMatch[1];
    }

    // 3. Try query parameter
    if (!tenantSlug && req.query.tenant) {
      tenantSlug = req.query.tenant as string;
    }

    // 4. Try header
    if (!tenantSlug && req.get('x-tenant-slug')) {
      tenantSlug = req.get('x-tenant-slug') || null;
    }

    // Set tenant context
    if (tenantSlug && oauthManager.getTenantConfig(tenantSlug)) {
      req.tenantSlug = tenantSlug;
      req.tenantId = oauthManager.getTenantConfig(tenantSlug)?.tenantId;
    }

    console.log(`OAuth: Tenant discovery - ${tenantSlug || 'none'} for ${req.path}`);
    next();
  } catch (error) {
    console.error('OAuth: Tenant discovery error:', error);
    next();
  }
};

// Create tenant-specific OAuth middleware
export const createTenantOAuthMiddleware = (tenantSlug: string) => {
  const config = oauthManager.getAuth0ConfigForTenant(tenantSlug);
  
  if (!config) {
    throw new Error(`OAuth configuration not found for tenant: ${tenantSlug}`);
  }

  console.log(`OAuth: Creating middleware for tenant ${tenantSlug}:`, {
    issuerBaseURL: config.issuerBaseURL,
    clientID: config.clientID,
    routes: config.routes
  });

  return auth(config);
};

// Dynamic OAuth middleware that selects configuration based on tenant
export const dynamicOAuthMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const tenantSlug = req.tenantSlug;
  
  if (!tenantSlug) {
    // Default OAuth for non-tenant-specific routes
    const { getDefaultOAuthConfig } = require('../config/oauth');
    const defaultConfig = getDefaultOAuthConfig();
    return auth(defaultConfig)(req, res, next);
  }

  try {
    const tenantMiddleware = createTenantOAuthMiddleware(tenantSlug);
    return tenantMiddleware(req, res, next);
  } catch (error) {
    console.error(`OAuth: Failed to create middleware for tenant ${tenantSlug}:`, error);
    return res.status(500).json({ 
      error: 'OAuth configuration error',
      tenant: tenantSlug 
    });
  }
};

// JWT validation middleware for API routes
export const validateJWT = (tenantSlug?: string) => {
  try {
    const config = getJWTValidationConfig(tenantSlug);
    
    return jwtCheck({
      issuerBaseURL: config.issuerBaseURL,
      audience: config.audience,
      algorithms: config.algorithms
    });
  } catch (error) {
    console.error('OAuth: JWT validation setup failed:', error);
    return (req: Request, res: Response, next: NextFunction) => {
      res.status(500).json({ error: 'JWT validation configuration error' });
    };
  }
};

// Role-based authorization middleware
export const requireRoles = (allowedRoles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.oidc?.isAuthenticated()) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const userRoles = req.userRoles || [];
    const hasAllowedRole = allowedRoles.some(role => userRoles.includes(role));
    
    if (!hasAllowedRole) {
      return res.status(403).json({ 
        error: 'Insufficient permissions',
        required: allowedRoles,
        actual: userRoles
      });
    }

    next();
  };
};

// Tenant isolation middleware
export const requireTenantAccess = (req: Request, res: Response, next: NextFunction) => {
  const requestedTenantId = req.params.tenantId || req.body.tenantId || req.query.tenantId;
  const userTenantId = req.tenantId;
  const userRoles = req.userRoles || [];

  // Platform owners can access all tenants
  if (userRoles.includes('PlatformOwner')) {
    return next();
  }

  // Users can only access their own tenant
  if (requestedTenantId && requestedTenantId !== userTenantId) {
    return res.status(403).json({ 
      error: 'Tenant access denied',
      requested: requestedTenantId,
      allowed: userTenantId
    });
  }

  next();
};

// Extract user context from OIDC claims
export const extractUserContext = (req: Request, res: Response, next: NextFunction) => {
  if (req.oidc?.isAuthenticated() && req.oidc.idTokenClaims) {
    const claims = req.oidc.idTokenClaims;
    
    // Extract standard claims
    req.tenantId = req.tenantId || claims['custom:tenant_id'] || claims.tenant_id;
    req.userRoles = claims['custom:roles'] || claims.roles || [];
    req.userPermissions = claims['custom:permissions'] || claims.permissions || [];

    // Log for debugging
    console.log(`OAuth: User context - ${claims.email}, roles: ${req.userRoles.join(',')}, tenant: ${req.tenantId}`);
  }
  
  next();
};

// OAuth health check middleware
export const oauthHealthCheck = (req: Request, res: Response, next: NextFunction) => {
  try {
    const tenantSlugs = oauthManager.getTenantSlugs();
    const status = {
      oauth: 'healthy',
      tenants: tenantSlugs.length,
      configuredTenants: tenantSlugs
    };

    res.json(status);
  } catch (error) {
    res.status(500).json({
      oauth: 'unhealthy',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
};

// Development-only middleware to simulate authentication
export const devSimulateAuth = (req: Request, res: Response, next: NextFunction) => {
  if (process.env.NODE_ENV !== 'development') {
    return next();
  }

  // Simulate OIDC authentication for development
  if (req.query.dev_user) {
    const devUser = req.query.dev_user as string;
    
    req.oidc = {
      isAuthenticated: () => true,
      idTokenClaims: {
        email: `${devUser}@example.com`,
        name: devUser,
        'custom:tenant_id': req.tenantId || 'acme-corp',
        'custom:roles': ['TenantOwner'],
        'custom:permissions': ['read', 'write', 'admin']
      }
    };
  }

  next();
};

// Combine all OAuth middleware for easy setup
export const setupOAuthMiddleware = () => {
  return [
    discoverTenant,
    extractUserContext,
    devSimulateAuth // Only active in development
  ];
};