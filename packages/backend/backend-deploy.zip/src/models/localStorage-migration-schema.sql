-- =====================================================
-- ADDITIONAL TABLES TO REPLACE LOCALSTORAGE USAGE
-- These complement the existing schema.sql
-- =====================================================

-- User Preferences - Replace localStorage for themes, UI settings, etc.
CREATE TABLE user_preferences (
    preference_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    user_id UNIQUEIDENTIFIER NOT NULL,
    
    -- Preference categories
    theme NVARCHAR(20) DEFAULT 'light', -- light, dark, system
    language NVARCHAR(10) DEFAULT 'en-US',
    timezone NVARCHAR(50) DEFAULT 'UTC',
    
    -- UI/UX preferences  
    ui_preferences NVARCHAR(MAX) DEFAULT '{}' CHECK (ISJSON(ui_preferences) = 1),
    notification_preferences NVARCHAR(MAX) DEFAULT '{}' CHECK (ISJSON(notification_preferences) = 1),
    
    -- Privacy settings
    privacy_settings NVARCHAR(MAX) DEFAULT '{}' CHECK (ISJSON(privacy_settings) = 1),
    
    -- Advanced settings
    advanced_settings NVARCHAR(MAX) DEFAULT '{}' CHECK (ISJSON(advanced_settings) = 1),
    
    -- Lifecycle
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    
    UNIQUE IX_user_preferences_tenant_user (tenant_id, user_id)
);

-- User Sessions - Replace localStorage auth tokens with secure server-side sessions
CREATE TABLE user_sessions (
    session_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    user_id UNIQUEIDENTIFIER NOT NULL,
    
    -- Session security
    session_token_hash NVARCHAR(64) NOT NULL, -- SHA-256 hash of session token
    csrf_token NVARCHAR(64) NOT NULL,
    
    -- Session metadata  
    client_ip NVARCHAR(45),
    user_agent NVARCHAR(500),
    device_fingerprint NVARCHAR(64),
    
    -- Session lifecycle
    expires_at DATETIME2 NOT NULL,
    last_activity_at DATETIME2 DEFAULT GETUTCDATE(),
    is_active BIT DEFAULT 1,
    
    -- Security flags
    is_mfa_verified BIT DEFAULT 0,
    force_password_change BIT DEFAULT 0,
    
    -- Timestamps
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    
    INDEX IX_user_sessions_token_hash (session_token_hash),
    INDEX IX_user_sessions_tenant_user (tenant_id, user_id),
    INDEX IX_user_sessions_expiry (expires_at),
    INDEX IX_user_sessions_cleanup (is_active, expires_at)
);

-- Agent Tools Configuration - More granular than the existing enabled_mcp_servers JSON
CREATE TABLE agent_tool_configurations (
    config_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    agent_id UNIQUEIDENTIFIER NOT NULL,
    server_id UNIQUEIDENTIFIER NOT NULL, -- From mcp_server_registry
    
    -- Tool-specific settings
    enabled_tools NVARCHAR(MAX) DEFAULT '[]' CHECK (ISJSON(enabled_tools) = 1), -- Specific tools enabled
    tool_settings NVARCHAR(MAX) DEFAULT '{}' CHECK (ISJSON(tool_settings) = 1), -- Tool-specific configuration
    
    -- Usage restrictions
    rate_limit_per_hour INT DEFAULT 100,
    max_concurrent_calls INT DEFAULT 5,
    
    -- Status
    is_enabled BIT DEFAULT 1,
    last_used_at DATETIME2,
    
    -- Lifecycle
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (agent_id) REFERENCES ai_agents(agent_id),
    FOREIGN KEY (server_id) REFERENCES mcp_server_registry(server_id),
    
    INDEX IX_agent_tool_configs_tenant_agent (tenant_id, agent_id),
    INDEX IX_agent_tool_configs_server (server_id),
    UNIQUE IX_agent_tool_configs_unique (tenant_id, agent_id, server_id)
);

-- Tenant Settings - Global tenant-level settings that were in localStorage  
CREATE TABLE tenant_settings (
    setting_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER NOT NULL,
    
    -- Organization settings
    organization_name NVARCHAR(255),
    organization_logo_url NVARCHAR(500),
    branding_colors NVARCHAR(MAX) DEFAULT '{}' CHECK (ISJSON(branding_colors) = 1),
    
    -- Default configurations
    default_llm_config_id UNIQUEIDENTIFIER,
    default_retention_days INT DEFAULT 90,
    
    -- Feature flags per tenant
    enabled_features NVARCHAR(MAX) DEFAULT '[]' CHECK (ISJSON(enabled_features) = 1),
    
    -- Security policies
    security_policies NVARCHAR(MAX) DEFAULT '{}' CHECK (ISJSON(security_policies) = 1),
    
    -- Compliance settings
    compliance_frameworks NVARCHAR(MAX) DEFAULT '[]' CHECK (ISJSON(compliance_frameworks) = 1),
    
    -- BYO LLM settings
    byollm_enabled BIT DEFAULT 0,
    byollm_allowed_providers NVARCHAR(MAX) DEFAULT '[]' CHECK (ISJSON(byollm_allowed_providers) = 1),
    
    -- Lifecycle
    created_at DATETIME2 DEFAULT GETUTCDATE(),
    updated_at DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (default_llm_config_id) REFERENCES llm_configurations(config_id),
    
    UNIQUE IX_tenant_settings_tenant_id (tenant_id)
);

-- Migration tracking table for localStorage data migration
CREATE TABLE localStorage_migration_log (
    migration_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    tenant_id UNIQUEIDENTIFIER,
    user_id UNIQUEIDENTIFIER,
    
    -- Migration details
    data_type NVARCHAR(50) NOT NULL, -- agents, mcp_servers, llm_configs, chat_sessions, preferences
    localStorage_key NVARCHAR(255) NOT NULL,
    migration_status NVARCHAR(20) NOT NULL, -- pending, completed, failed
    
    -- Data details
    record_count INT DEFAULT 0,
    migration_data NVARCHAR(MAX), -- JSON of migrated data for verification
    error_details NVARCHAR(MAX),
    
    -- Timestamps
    started_at DATETIME2 DEFAULT GETUTCDATE(),
    completed_at DATETIME2,
    
    FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    
    INDEX IX_localStorage_migration_tenant (tenant_id),
    INDEX IX_localStorage_migration_status (migration_status),
    INDEX IX_localStorage_migration_data_type (data_type)
);

-- Triggers for updated_at timestamps on new tables
GO
CREATE TRIGGER tr_update_timestamps_user_preferences ON user_preferences AFTER UPDATE AS 
BEGIN
    UPDATE user_preferences SET updated_at = GETUTCDATE() 
    WHERE preference_id IN (SELECT preference_id FROM inserted);
END;
GO

CREATE TRIGGER tr_update_timestamps_user_sessions ON user_sessions AFTER UPDATE AS 
BEGIN
    UPDATE user_sessions SET updated_at = GETUTCDATE(), last_activity_at = GETUTCDATE()
    WHERE session_id IN (SELECT session_id FROM inserted);
END;
GO

CREATE TRIGGER tr_update_timestamps_tenant_settings ON tenant_settings AFTER UPDATE AS 
BEGIN
    UPDATE tenant_settings SET updated_at = GETUTCDATE() 
    WHERE setting_id IN (SELECT setting_id FROM inserted);
END;
GO

CREATE TRIGGER tr_update_timestamps_agent_tool_configurations ON agent_tool_configurations AFTER UPDATE AS 
BEGIN
    UPDATE agent_tool_configurations SET updated_at = GETUTCDATE() 
    WHERE config_id IN (SELECT config_id FROM inserted);
END;
GO