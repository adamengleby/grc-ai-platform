-- GRC AI Platform Database Schema
-- Multi-tenant SaaS architecture with proper isolation

-- =======================
-- TENANT MANAGEMENT
-- =======================

CREATE TABLE tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    domain VARCHAR(255),
    subscription_plan VARCHAR(50) DEFAULT 'free',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(name),
    UNIQUE(domain)
);

-- =======================
-- USER MANAGEMENT
-- =======================

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    role VARCHAR(50) DEFAULT 'user', -- 'admin', 'owner', 'user'
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, email)
);

-- =======================
-- LLM CONFIGURATIONS
-- =======================

CREATE TABLE llm_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    created_by UUID NOT NULL REFERENCES users(id),
    name VARCHAR(255) NOT NULL,
    provider VARCHAR(100) NOT NULL, -- 'openai', 'azure-openai', 'anthropic', etc.
    model VARCHAR(255) NOT NULL,
    api_endpoint TEXT,
    api_key_vault_reference TEXT, -- Reference to Azure Key Vault secret
    max_tokens INTEGER DEFAULT 4000,
    temperature DECIMAL(3,2) DEFAULT 0.7,
    is_enabled BOOLEAN DEFAULT true,
    is_default BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, name)
);

-- =======================
-- MCP SERVER REGISTRY (Global)
-- =======================

CREATE TABLE mcp_server_registry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    version VARCHAR(50),
    publisher VARCHAR(255),
    category VARCHAR(100),
    npm_package VARCHAR(255),
    git_repository TEXT,
    documentation_url TEXT,
    is_approved BOOLEAN DEFAULT false,
    approval_date TIMESTAMP,
    security_scan_status VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =======================
-- TENANT MCP SERVER CONFIGURATIONS
-- =======================

CREATE TABLE tenant_mcp_servers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    mcp_server_id UUID NOT NULL REFERENCES mcp_server_registry(id),
    enabled_by UUID NOT NULL REFERENCES users(id),
    name VARCHAR(255) NOT NULL, -- Tenant-specific name override
    description TEXT,
    connection_config JSONB, -- Connection parameters
    health_check_config JSONB,
    rate_limits JSONB,
    is_enabled BOOLEAN DEFAULT true,
    enabled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_health_check TIMESTAMP,
    health_status VARCHAR(50) DEFAULT 'unknown',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, mcp_server_id)
);

-- =======================
-- AI AGENT CONFIGURATIONS
-- =======================

CREATE TABLE ai_agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    created_by UUID NOT NULL REFERENCES users(id),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    persona TEXT,
    system_prompt TEXT NOT NULL,
    llm_config_id UUID REFERENCES llm_configs(id),
    avatar VARCHAR(10), -- Emoji
    color VARCHAR(7), -- Hex color
    is_enabled BOOLEAN DEFAULT true,
    usage_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, name)
);

-- =======================
-- AGENT MCP SERVER ASSOCIATIONS
-- =======================

CREATE TABLE agent_mcp_servers (
    agent_id UUID NOT NULL REFERENCES ai_agents(id) ON DELETE CASCADE,
    tenant_mcp_server_id UUID NOT NULL REFERENCES tenant_mcp_servers(id) ON DELETE CASCADE,
    enabled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (agent_id, tenant_mcp_server_id)
);

-- =======================
-- AGENT EXECUTION METRICS
-- =======================

CREATE TABLE agent_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES ai_agents(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id),
    status VARCHAR(20) NOT NULL, -- 'success', 'error', 'timeout'
    duration_ms INTEGER,
    tokens_used INTEGER,
    cost_usd DECIMAL(10,6),
    error_message TEXT,
    execution_context JSONB,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

-- =======================
-- TENANT SETTINGS
-- =======================

CREATE TABLE tenant_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    category VARCHAR(100) NOT NULL, -- 'privacy', 'security', 'billing', etc.
    settings_json JSONB NOT NULL,
    updated_by UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, category)
);

-- =======================
-- ARCHER CONNECTIONS
-- =======================

CREATE TABLE archer_connections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    created_by UUID NOT NULL REFERENCES users(id),
    name VARCHAR(255) NOT NULL,
    base_url TEXT NOT NULL,
    username_vault_reference TEXT NOT NULL, -- Azure Key Vault reference
    password_vault_reference TEXT NOT NULL, -- Azure Key Vault reference
    instance_id VARCHAR(255),
    user_domain_id VARCHAR(255),
    is_enabled BOOLEAN DEFAULT true,
    last_connection_test TIMESTAMP,
    connection_status VARCHAR(50) DEFAULT 'unknown',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenant_id, name)
);

-- =======================
-- AUDIT LOGS (WORM - Write Once Read Many)
-- =======================

CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(100) NOT NULL,
    resource_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    session_id UUID,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- WORM: No updates or deletes allowed
    CONSTRAINT no_updates CHECK (false) DEFERRABLE INITIALLY DEFERRED
);

-- =======================
-- INDEXES FOR PERFORMANCE
-- =======================

-- Tenant isolation indexes
CREATE INDEX idx_users_tenant_id ON users(tenant_id);
CREATE INDEX idx_llm_configs_tenant_id ON llm_configs(tenant_id);
CREATE INDEX idx_tenant_mcp_servers_tenant_id ON tenant_mcp_servers(tenant_id);
CREATE INDEX idx_ai_agents_tenant_id ON ai_agents(tenant_id);
CREATE INDEX idx_tenant_settings_tenant_id ON tenant_settings(tenant_id);
CREATE INDEX idx_archer_connections_tenant_id ON archer_connections(tenant_id);

-- Performance indexes
CREATE INDEX idx_agent_executions_agent_id ON agent_executions(agent_id);
CREATE INDEX idx_agent_executions_started_at ON agent_executions(started_at);
CREATE INDEX idx_audit_logs_tenant_timestamp ON audit_logs(tenant_id, timestamp);
CREATE INDEX idx_audit_logs_resource ON audit_logs(resource_type, resource_id);

-- =======================
-- ROW LEVEL SECURITY
-- =======================

-- Enable RLS on all tenant-specific tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE llm_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenant_mcp_servers ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenant_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE archer_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Example RLS policies (would be expanded for each table)
CREATE POLICY tenant_isolation_users ON users
    FOR ALL TO application_user
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);

-- =======================
-- SAMPLE DATA
-- =======================

-- Insert default tenant for development
INSERT INTO tenants (id, name, display_name, domain) VALUES 
    ('00000000-0000-0000-0000-000000000001', 'demo-tenant', 'Demo Tenant', 'demo.example.com');

-- Insert default admin user
INSERT INTO users (id, tenant_id, email, full_name, role) VALUES 
    ('00000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001', 'admin@demo.example.com', 'Admin User', 'owner');